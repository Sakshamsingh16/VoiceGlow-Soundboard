package com.voiceglow.soundboard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class FloatingVoiceService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.US
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) startForeground(41, notification())
        val phrase = intent?.getStringExtra("speak")
        if (!phrase.isNullOrBlank()) speak(phrase)
        if (intent?.getBooleanExtra("start_overlay", false) == true) showBubble()
        return START_STICKY
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("voiceglow", "VoiceGlow overlay", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "voiceglow")
                .setContentTitle("VoiceGlow is ready")
                .setContentText("Floating voice bubble is active")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("VoiceGlow").setContentText("Floating voice bubble is active")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        }
    }

    private fun showBubble() {
        if (bubble != null) return
        bubble = TextView(this).apply {
            text = "VG"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(20, 173, 85), Color.rgb(218, 45, 58))).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.WHITE)
            }
            setOnClickListener { togglePanel() }
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58),
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(10); y = dp(180) }
        try { wm.addView(bubble, params) } catch (e: Exception) { Toast.makeText(this, "Overlay permission is needed.", Toast.LENGTH_LONG).show() }
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.rgb(215, 235, 221))
            }
        }
        val header = TextView(this).apply {
            text = "VOICEGLOW  ×"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(24, 45, 31)); gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
            setOnClickListener { closePanel() }
        }
        p.addView(header)
        val voices = listOf(
            "❤️  I Love You" to "I love you",
            "😂  Funny laugh" to "Ha ha ha!",
            "👋  Hello bro" to "Hello bro!",
            "😎  Let's go!" to "Let's go!"
        )
        voices.forEach { (label, phrase) ->
            val b = TextView(this).apply {
                text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(24, 111, 59)); gravity = Gravity.CENTER
                setPadding(dp(8), dp(11), dp(8), dp(11))
                background = GradientDrawable().apply {
                    setColor(Color.rgb(232, 248, 237)); cornerRadius = dp(12).toFloat()
                }
                setOnClickListener { speak(phrase); Toast.makeText(this@FloatingVoiceService, "Playing: $label", Toast.LENGTH_SHORT).show() }
            }
            val lp = LinearLayout.LayoutParams(dp(190), dp(46)); lp.bottomMargin = dp(7)
            p.addView(b, lp)
        }
        val hint = TextView(this).apply {
            text = "Custom voices: open the app"
            textSize = 11f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
        }
        p.addView(hint)
        panel = p
        val params = WindowManager.LayoutParams(
            dp(220), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(10); y = dp(245) }
        try { wm.addView(panel, params) } catch (_: Exception) { panel = null }
    }

    private fun closePanel() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
    }

    private fun speak(phrase: String) {
        if (ttsReady) {
            if (Build.VERSION.SDK_INT >= 21) tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "voiceglow-${System.currentTimeMillis()}")
            else { @Suppress("DEPRECATION") tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null) }
        } else Toast.makeText(this, "Voice engine is loading. Try again.", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        closePanel()
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
