package com.voiceglow.soundboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var player: MediaPlayer? = null
    private var isRecording = false

    private val prefs by lazy { getSharedPreferences("voiceglow", MODE_PRIVATE) }

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importAudio(uri)
    }

    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else toast("Microphone permission is required to record.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 248, 246)
        window.navigationBarColor = Color.rgb(245, 248, 246)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 248, 246))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "◉"
            textSize = 28f
            setTextColor(Color.rgb(16, 166, 83))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 18, "#DDEFE4", 1)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleBox.addView(label("VoiceGlow", 25, "#17221B", true))
        titleBox.addView(label("Gaming voice soundboard", 13, "#6D7B72", false))
        top.addView(logo)
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(label("● LIVE", 12, "#169A50", true))
        content.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = roundedGradient()
        }
        val heroTitle = label("Your voice. One tap.", 22, "#FFFFFF", true)
        hero.addView(heroTitle)
        val heroSub = label("Quick sounds for your gaming sessions", 14, "#E4F9EA", false)
        val subParams = LinearLayout.LayoutParams(-1, -2); subParams.topMargin = dp(7)
        hero.addView(heroSub, subParams)
        val overlayBtn = button("Enable floating bubble", "#FFFFFF", "#14884A")
        val obp = LinearLayout.LayoutParams(-1, dp(48)); obp.topMargin = dp(18)
        hero.addView(overlayBtn, obp)
        overlayBtn.setOnClickListener { enableOverlay() }
        val hp = LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(22)
        content.addView(hero, hp)

        val sectionRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sectionRow.addView(label("Quick voices", 20, "#17221B", true), LinearLayout.LayoutParams(0, -2, 1f))
        sectionRow.addView(label("Tap to play", 12, "#7A877F", false))
        val srp = LinearLayout.LayoutParams(-1, -2); srp.topMargin = dp(24)
        content.addView(sectionRow, srp)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(voiceCard("❤️", "I Love You", "Preset phrase", "I love you"))
        row1.addView(voiceCard("😂", "Funny laugh", "Preset phrase", "Ha ha ha!"))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(voiceCard("👋", "Hello bro", "Preset phrase", "Hello bro!"))
        row2.addView(voiceCard("😎", "Let's go!", "Preset phrase", "Let's go!"))
        grid.addView(row1); grid.addView(row2)
        val gp = LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(10)
        content.addView(grid, gp)

        content.addView(label("My voice library", 20, "#17221B", true).apply {
            val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(26); layoutParams = p
        })
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val upload = button("＋  Upload audio", "#E4F6EA", "#137D42")
        upload.setOnClickListener { audioPicker.launch(arrayOf("audio/*")) }
        val record = button("●  Record voice", "#E7F0FF", "#275DB2")
        record.setOnClickListener { toggleRecording() }
        val tp1 = LinearLayout.LayoutParams(0, dp(48), 1f); tp1.marginEnd = dp(6)
        val tp2 = LinearLayout.LayoutParams(0, dp(48), 1f); tp2.marginStart = dp(6)
        tools.addView(upload, tp1); tools.addView(record, tp2)
        val toolp = LinearLayout.LayoutParams(-1, -2); toolp.topMargin = dp(14)
        content.addView(tools, toolp)

        val hint = label("Upload an audio clip or record your own voice. Clips stay on this device.", 13, "#748078", false)
        val hip = LinearLayout.LayoutParams(-1, -2); hip.topMargin = dp(10)
        content.addView(hint, hip)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(12)
        content.addView(list, lp)
        refreshVoices()

        val footer = label("Note: voice playback uses your phone's audio output. Free Fire may not route it into team voice chat on every device.", 12, "#78837C", false)
        val fp = LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(20)
        content.addView(footer, fp)

        setContentView(root)
    }

    private fun voiceCard(emoji: String, title: String, subtitle: String, phrase: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.WHITE, 18, "#E0E9E3", 1)
            isClickable = true
            isFocusable = true
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(label(emoji, 24, "#17221B", true))
        top.addView(label("▶", 14, "#17A452", true).apply {
            gravity = Gravity.CENTER
            background = rounded("#E1F6E8", 30, "#E1F6E8", 0)
            val p = LinearLayout.LayoutParams(dp(32), dp(32)); p.gravity = Gravity.END; layoutParams = p
        }, LinearLayout.LayoutParams(0, dp(32), 1f))
        card.addView(top)
        val t = label(title, 15, "#1D2921", true); val tp = LinearLayout.LayoutParams(-1, -2); tp.topMargin = dp(12); card.addView(t, tp)
        val st = label(subtitle, 11, "#7C887F", false); val sp = LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(4); card.addView(st, sp)
        card.setOnClickListener { speak(phrase) }
        val p = LinearLayout.LayoutParams(0, dp(132), 1f)
        p.marginEnd = dp(5); p.marginStart = dp(5); p.topMargin = dp(5); p.bottomMargin = dp(5)
        card.layoutParams = p
        return card
    }

    private fun refreshVoices() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val names = prefs.getString("voice_names", "")!!.split("\n").filter { it.isNotBlank() }
        val files = prefs.getString("voice_files", "")!!.split("\n").filter { it.isNotBlank() }
        if (names.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No custom voices yet"
                textSize = 14f; setTextColor(Color.rgb(120, 132, 124))
                gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20))
            }
            list.addView(empty)
            return
        }
        names.indices.forEach { i ->
            if (i >= files.size) return@forEach
            val file = File(filesDir, files[i])
            if (!file.exists()) return@forEach
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(10), dp(12))
                background = rounded(Color.WHITE, 14, "#E0E9E3", 1)
            }
            val name = TextView(this).apply { text = "🎙  ${names[i]}"; textSize = 14f; setTextColor(Color.rgb(29,41,33)); setTypeface(null, Typeface.BOLD) }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val play = button("▶", "#E1F6E8", "#137D42")
            play.setOnClickListener { playFile(file) }
            row.addView(play, LinearLayout.LayoutParams(dp(46), dp(40)))
            val del = button("×", "#FFF0F0", "#C62828")
            del.setOnClickListener {
                file.delete()
                val newNames = names.toMutableList().also { it.removeAt(i) }
                val newFiles = files.toMutableList().also { it.removeAt(i) }
                prefs.edit().putString("voice_names", newNames.joinToString("\n")).putString("voice_files", newFiles.joinToString("\n")).apply()
                refreshVoices()
            }
            val dp2 = LinearLayout.LayoutParams(dp(44), dp(40)); dp2.marginStart = dp(6)
            row.addView(del, dp2)
            val rp = LinearLayout.LayoutParams(-1, -2); rp.bottomMargin = dp(8)
            list.addView(row, rp)
        }
    }

    private fun toggleRecording() {
        if (isRecording) {
            try {
                recorder?.stop()
                recorder?.release()
                recorder = null
                isRecording = false
                recordingFile?.let { saveVoice(it, "My voice ${SimpleDateFormat("HHmmss", Locale.getDefault()).format(Date())}") }
                toast("Voice recording saved")
                recreate()
            } catch (e: Exception) {
                recorder?.release(); recorder = null; isRecording = false
                toast("Recording was too short. Try again.")
            }
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else startRecording()
    }

    private fun startRecording() {
        try {
            val file = File(filesDir, "voice_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath)
            r.prepare(); r.start()
            recorder = r; recordingFile = file; isRecording = true
            toast("Recording… tap Record voice again to save")
        } catch (e: Exception) {
            toast("Could not start recording: ${e.message}")
        }
    }

    private fun importAudio(uri: Uri) {
        try {
            var name = "Imported voice"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) name = c.getString(idx) ?: name
            }
            val safeName = name.substringBeforeLast('.', name).take(32).ifBlank { "Imported voice" }
            val file = File(filesDir, "voice_${System.currentTimeMillis()}.audio")
            contentResolver.openInputStream(uri).use { input ->
                FileOutputStream(file).use { output -> input?.copyTo(output) ?: throw Exception("Can't read selected file") }
            }
            saveVoice(file, safeName)
            toast("Audio added to your voice library")
            refreshVoices()
        } catch (e: Exception) { toast("Import failed: ${e.message}") }
    }

    private fun saveVoice(file: File, name: String) {
        val names = prefs.getString("voice_names", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        val files = prefs.getString("voice_files", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        names.add(name); files.add(file.name)
        prefs.edit().putString("voice_names", names.joinToString("\n")).putString("voice_files", files.joinToString("\n")).apply()
        refreshVoices()
    }

    private fun playFile(file: File) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); player = null }
                setOnErrorListener { mp, _, _ -> mp.release(); player = null; true }
                prepare(); start()
            }
        } catch (e: Exception) { toast("Can't play this audio format.") }
    }

    private fun speak(text: String) {
        val intent = Intent(this, FloatingVoiceService::class.java).putExtra("speak", text)
        if (Build.VERSION.SDK_INT >= 26) startService(intent) else startService(intent)
        // TTS preset phrases are spoken by the service so they also work from the overlay.
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Allow 'Display over other apps', then return and tap again.")
        } else {
            val intent = Intent(this, FloatingVoiceService::class.java).putExtra("start_overlay", true)
            ContextCompat.startForegroundService(this, intent)
            toast("Floating bubble enabled")
        }
    }

    private fun button(text: String, bg: String, fg: String): TextView {
        return TextView(this).apply {
            this.text = text; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor(fg)); setTypeface(null, Typeface.BOLD)
            background = rounded(bg, 14, bg, 0)
            isClickable = true; isFocusable = true
        }
    }

    private fun label(text: String, size: Int, color: String, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size.toFloat(); setTextColor(Color.parseColor(color))
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int, stroke: String, strokeWidth: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (strokeWidth > 0) setStroke(dp(strokeWidth), Color.parseColor(stroke))
        }

    private fun rounded(color: String, radius: Int, stroke: String, strokeWidth: Int): GradientDrawable =
        rounded(Color.parseColor(color), radius, stroke, strokeWidth)

    private fun roundedGradient() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(14, 112, 61), Color.rgb(22, 169, 85), Color.rgb(223, 45, 58))
    ).apply { cornerRadius = dp(24).toFloat() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        try { player?.release() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
