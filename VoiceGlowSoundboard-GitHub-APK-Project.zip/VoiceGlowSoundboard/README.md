# VoiceGlow Soundboard

A starter Android project for a light-mode gaming voice soundboard with red/green accents.

## Features
- Light UI with soft green/red gradient hero panel
- One-tap preset phrase buttons (Android Text-to-Speech)
- Import audio files from the device
- Record and save your own voice clips locally
- Floating overlay bubble with preset voice buttons
- GitHub Actions workflow to build a debug APK

## Build on GitHub
1. Upload the contents of this ZIP to a new GitHub repository (or upload the ZIP and extract it in the repository).
2. Open **Actions** and enable workflows if prompted.
3. Run **Build Android APK** from the Actions tab, or push a commit.
4. Download `VoiceGlow-debug-apk` from the completed workflow run's Artifacts section.

## Important audio limitation
Android normally does not let a regular app inject audio directly into another app's microphone input. The preset phrases use Android Text-to-Speech, and imported/recorded clips play through the phone's audio output. Whether teammates hear the sound depends on the game's mic routing, device audio processing, and speaker/microphone setup. This is not guaranteed.

## Requirements
- Android Studio with JDK 17
- Android SDK 35
